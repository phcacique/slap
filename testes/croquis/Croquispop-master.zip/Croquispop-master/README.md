Croquispop
==========

The demo project of [croquis.js](https://github.com/disjukr/croquis.js).

If you want to know usage of `croquis.js`, see `croquispop.html`.
And see `brush-preview.html` to know how brush tool works.